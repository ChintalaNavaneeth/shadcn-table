"use client";

import { ColumnDef } from "@tanstack/react-table";
import { SortableHeader } from "@/components/data-table/SortableHeader";
import { Project } from "./data";
import { toast } from "sonner";
import ProjectName from "@/components/data-table/ProjectName";
import ProjectLastUpdate from "@/components/data-table/ProjectLastUpdate";
import ProjectResources from "@/components/data-table/ProjectResources";
import ProjectTimeLine from "@/components/data-table/ProjectTimeLine";

const copyRowToClipboard = (row: Project) => {
  const rowJson = JSON.stringify(row);

  navigator.clipboard.writeText(rowJson).then(
    () => {toast.success("Row copied to clipboard!");},
    (err) => {toast.error("Failed to copy row: " + err);}
  );
};

export const columns: ColumnDef<Project>[] = [
  {
    id: "actions",
    header: "",
    cell: ({ row }) => (
      <div>
          <button
          onClick={() => copyRowToClipboard(row.original)}
          className="text-black text-lg hover:text-gray-700 flex justify-center items-center w-[40px] h-[40px] rounded-full"
          title="Copy row data in json format"
        >
          ...
        </button>
      </div>
    ),
    enableSorting: false,
    enableHiding: false,
  },

  {
    accessorKey: "name",
    header: ({ column }) => (
      <SortableHeader column={column} title="Project name" />
    ),
    cell: ({ row }) => <ProjectName name={row.getValue("name")} />,
    enableSorting: true,
  },
  {
    accessorKey: "last_updated",
    header: ({ column }) => (
      <SortableHeader column={column} title="Last updated" />
    ),
    cell: ({ row }) => (
      <ProjectLastUpdate date={row.getValue("last_updated")} />
    ),
    enableSorting: true,
  },
  {
    accessorKey: "resources",
    header: "Resources",
    cell: ({ row }) => (
      <ProjectResources resources={row.getValue("resources")} />
    ),
  },
  {
    accessorKey: "start_date",
    header: "Project timeline",
    cell: ({ row }) => (
      <ProjectTimeLine
        startDate={row.original.start_date}
        endDate={row.original.end_date}
      />
    ),
  },
  {
    accessorKey: "estimated_cost",
    header: ({ column }) => (
      <SortableHeader column={column} title="Estimated cost" />
    ),
    enableSorting: true,
  }
];
