import { Button } from "@/components/ui/button";
import SearchBar from "./SearchBar";

const TopHeader = () => {
  return (
    <div>
      <h4 className="text-2xl font-semibold text-gray-800 mt-8 ml-8">VULNERABILITY DATA</h4>
      <div className="flex flex-row justify-between items-center px-8 pt-8">
        <SearchBar/>
        <Button className="bg-purple-500 text-white hover:bg-purple-600"> View Columns </Button>
      </div>
    </div>
  );
};

export default TopHeader;
