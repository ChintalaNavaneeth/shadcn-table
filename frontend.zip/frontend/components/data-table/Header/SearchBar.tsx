import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, FilterIcon, SearchIcon } from "lucide-react";

const SearchBar = () => {
  return (
    <div className="flex flex-row items-center h-[2.45rem] rounded-lg shadow-sm">
      <DropdownMenu>
        <DropdownMenuTrigger className="flex flex-row items-center h-full px-[1.025rem] rounded-l-lg border gap-2 text-sm">
          <FilterIcon className="w-[1.2rem] h-[1.2rem]" fill="currentColor" />
          Filter By
          <ChevronDown className="w-[1.2rem] h-[1x.2rem]" />
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem>Scan Type</DropdownMenuItem>
          <DropdownMenuItem>PSR SSO</DropdownMenuItem>
          <DropdownMenuItem>PSR Name</DropdownMenuItem>
          <DropdownMenuItem>PSL SSO</DropdownMenuItem>
          <DropdownMenuItem>PSL Name</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <div className="flex flex-row items-center rounded-r-lg border border-l-0 h-full relative">
        <SearchIcon className="w-[1.2rem] h-[1.2rem] ml-[1.15rem] absolute text-black-400" />
        <input
          type="text"
          placeholder="Search..."
          className="h-full py-[0.5rem] px-[2.015rem] border text-m w-[40.36rem] rounded-r-lg pl-[3.16rem]"
        />
      </div>
    </div>
  );
};

export default SearchBar;
